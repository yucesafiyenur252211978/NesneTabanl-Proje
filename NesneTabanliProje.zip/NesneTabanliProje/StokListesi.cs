﻿using FireSharp;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;


namespace NesneTabanliProje
{
    //Bu form, Firebase’deki stok kayıtlarını çekip DataGridView’de listeleyen bir ekrandır.
    public partial class frmStokListesi : Form  // sınıf tanımı
    {
        frmYeniStokKayit frm = new frmYeniStokKayit();  //Form içinde başka bir form tanımlama

        public frmStokListesi()
        {
            InitializeComponent(); //Ekrandaki butonlar, grid vb. yüklenir.
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect; // Constructor form açılırken yüklenirler. 
            dataGridView1.MultiSelect = false;
        }
        public string id;
        public string stokadi;
        public string stokbirim;
        public string stokalisfiyati;           // public değişkenler Seçilen stok bilgilerini başka formlara aktarmak için kullanılır.
        public string stoksatisfiyati;
        public string aciklama;

        public async void Listele()    //Firebase’den stokları çekip DataGridView’de listelemek
        {
            IFirebaseConfig config = new FirebaseConfig   //Firebase bağlantısı
            {
                AuthSecret = "egJlGzibXtQewvhJtCfYSAvV6unuXRFSmnoMMzwb",
                BasePath = "https://nesnetabanliproje-333e4-default-rtdb.firebaseio.com/"
            };

            IFirebaseClient client = new FirebaseClient(config);    //Firebase ile iletişim kuracak nesnedir. 
            var data = await client.GetTaskAsync("Stok");           // veriyi firebaseden çeker.

            Dictionary<string, Data> data1 = data.ResultAs<Dictionary<string, Data>>();

            foreach (var data2 in data1)
            {
                dataGridView1.Rows.Add(data2.Value.StokID, 
                    data2.Value.StokAdi,
                    data2.Value.StokBirim,
                    data2.Value.StokAlisFiyati,          //Firebase’den gelen her stok Grid’e satır satır eklenir Kullanıcı ekranda tüm stokları görür.
                    data2.Value.StokSatisFiyati,
                    data2.Value.Acikalama);

            }
        }

        private async void StokListesi_Load(object sender, EventArgs e)
        {
            Listele();
        }

        private async void SagTikSil_Click(object sender, EventArgs e)
        {
            //DataGridView’de seçilen satırdan stok ID alınır
            //Firebase’e bağlanılır Stok / id yolu silinir
            //Kullanıcıya mesaj gösterilir
            //Grid temizlenir ve liste yenilenir

            id = dataGridView1.SelectedCells[0].Value.ToString();
            IFirebaseConfig config = new FirebaseConfig
            {
                AuthSecret = "egJlGzibXtQewvhJtCfYSAvV6unuXRFSmnoMMzwb",
                BasePath = "https://nesnetabanliproje-333e4-default-rtdb.firebaseio.com/"
            };

            IFirebaseClient client = new FirebaseClient(config);
            var data= await client.DeleteTaskAsync("Stok/"+id);
            MessageBox.Show("Kayıt silindi..");
            dataGridView1.Rows.Clear();
            Listele();
        }

        private async void SagTikDüzenle_Click(object sender, EventArgs e)
        {

            //Seçilen satırdan: ID ,Stok adı, Birim, Alış / satış fiyatı, Açıklama bilgileri alınır.
            //Bu bilgiler frmYeniStokKayit formuna aktarılır Form dialog olarak açılır
            //Form kapandıktan sonra: Grid temizlenir Liste tekrar yüklenir


            id = dataGridView1.SelectedCells[0].Value.ToString();
            stokadi= dataGridView1.SelectedCells[1].Value.ToString();
            stokbirim= dataGridView1.SelectedCells[2].Value.ToString();
            stokalisfiyati= dataGridView1.SelectedCells[3].Value.ToString();
            stoksatisfiyati= dataGridView1.SelectedCells[4].Value.ToString();
            aciklama= dataGridView1.SelectedCells[5].Value.ToString();
            

            frm.id = id;
            frm.aciklama = aciklama;
            frm.stokadi = stokadi;
            frm.stokalisfiyati = stokalisfiyati;
            frm.stoksatisfiyati = stoksatisfiyati;
            frm.stokbirim = stokbirim;
            frm.ShowDialog();
            dataGridView1.Rows.Clear();
            Listele();

        }

        private void SagTikYeniKayit_Click(object sender, EventArgs e)
        {
            //Yeni frmYeniStokKayit formu açılır  Kullanıcı kayıt ekler
            //Form kapandıktan sonra Grid temizlenir Liste güncellenir


            frmYeniStokKayit frm = new frmYeniStokKayit();
            frm.ShowDialog();
            dataGridView1.Rows.Clear();
            Listele();
        }

        private void btnAra_Click(object sender, EventArgs e)
        {
            //Firebase’deki stoklar arasında arama yapar

            if (txtArama.Text==""&& comboBox1.Text=="")
            {
                MessageBox.Show("Boş Alanları Dolsurunuz...");
            }
          else
            {
                IFirebaseConfig config = new FirebaseConfig
                {
                    AuthSecret = "egJlGzibXtQewvhJtCfYSAvV6unuXRFSmnoMMzwb",
                    BasePath = "https://nesnetabanliproje-333e4-default-rtdb.firebaseio.com/"
                };

                IFirebaseClient client = new FirebaseClient(config);

                FirebaseResponse response = client.Get("Stok/");   //Firebase’den tüm stokları çekme.
                Dictionary<string, Data> getData = response.ResultAs<Dictionary<string, Data>>();

                dataGridView1.Rows.Clear();

                foreach (var get in getData)
                {
                    if (comboBox1.Text == "STOK ID")
                    {
                        string StokID = get.Value.StokID;
                        if (StokID == txtArama.Text)
                        {
                            dataGridView1.Rows.Add(get.Value.StokID,
                                get.Value.StokAdi,
                                get.Value.StokBirim,
                                get.Value.StokAlisFiyati,
                                get.Value.StokSatisFiyati,
                                get.Value.Acikalama);

                        }
                    }
                    if (comboBox1.Text == "STOK ADI")
                    {
                        string StokAdi = get.Value.StokAdi;
                        if (StokAdi == txtArama.Text)
                        {
                            dataGridView1.Rows.Add(get.Value.StokID,
                                get.Value.StokAdi,
                                get.Value.StokBirim,
                                get.Value.StokAlisFiyati,
                                get.Value.StokSatisFiyati,
                                get.Value.Acikalama);

                        }
                    }
                    if (comboBox1.Text == "AÇIKLAMA")
                    {
                        string aciklama = get.Value.Acikalama;
                        if (aciklama == txtArama.Text)
                        {
                            dataGridView1.Rows.Add(get.Value.StokID,
                                get.Value.StokAdi,
                                get.Value.StokBirim,
                                get.Value.StokAlisFiyati,
                                get.Value.StokSatisFiyati,
                                get.Value.Acikalama);

                        }
                    }
                }
            }
       
        
        }
    }
}
