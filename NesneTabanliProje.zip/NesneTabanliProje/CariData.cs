﻿namespace NesneTabanliProje
{
    internal class CariData
    {
        public string CariID { get; set; }
        public string CariAdi { get; set; }
        public string VergiDairesi { get; set; }
        public string VergiNo { get; set; }
        public string Adres { get; set; }
        public string Sehir { get; set; }
        public string Telefon { get; set; }
        public string YetkiliKisi { get; set; }
        public string Aciklama { get; set; }
    }
}