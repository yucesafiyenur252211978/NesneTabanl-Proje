﻿namespace NesneTabanliProje
{//https://console.firebase.google.com/project/nesnetabanliproje-333e4/database/nesnetabanliproje-333e4-default-rtdb/data
    internal class Data
    {
        internal static Data result;
        //Stok bilgileri Data sınıfı içinde kapsüllendi ve property yapısı ile kontrollü erişim sağlandı.
        public string StokID { get; set; }
        public string StokAdi { get; set; }
        public string StokBirim { get; set; }
        public int StokAlisFiyati { get; set; }
        public int StokSatisFiyati { get; set; }
        public string Acikalama { get; set; }
    }
}