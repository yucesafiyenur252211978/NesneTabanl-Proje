﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;

using System.Net.NetworkInformation;
using System.Net;
using System.Net.NetworkInformation;
namespace NesneTabanliProje
{

    //Bu form uygulamanın ana ekranıdır.
    //Program açıldığında önce internet bağlantısı kontrol edilir, ardından Firebase veritabanına bağlanılır.
    //Bağlantı başarılıysa kullanıcıya bilgi verilir.
    //Menü üzerinden stok ve cari kayıt işlemleri için ilgili formlar açılır.
    public partial class Form1 : Form   //Form Tanımı Uygulama açıldığında gelen ana ekran.  
    {    //Stok bilgileri Data sınıfı içinde kapsüllendi ve property yapısı ile kontrollü erişim sağlandı.
        IFirebaseConfig config = new FirebaseConfig
        { //Firebase Bağlantı Ayarları Firebase veritabanına bağlanmak için gerekli ayarlar.
            AuthSecret = "egJlGzibXtQewvhJtCfYSAvV6unuXRFSmnoMMzwb",
            BasePath = "https://nesnetabanliproje-333e4-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;   //client → Firebase işlemlerini yapan nesne
        public Form1()
        {
            InitializeComponent();
        }

        static bool baglantiKontrol()
        {
            //İnternet Bağlantı Kontrolü
            //Google’a Ping atar Cevap gelirse → internet var Hata olursa → internet yok
            try
            {
                return new System.Net.NetworkInformation.Ping().Send("www.google.com", 1000).Status == System.Net.NetworkInformation.IPStatus.Success;
            }
            catch(Exception)
            {
                return false;
            }
        }

        
        private void Form1_Load(object sender, EventArgs e)
        {
            //Form açılır açılmaz:

            if (baglantiKontrol()== false)
            {  //İnternet yoksa 
                MessageBox.Show("İNternet bağlantınızı kontrol ediniz...");
                this.Close();
            }
            else
            {
                client = new FireSharp.FirebaseClient(config);

                if (client != null)
                { //İnternet varsa
                    MessageBox.Show("Bağlantı başarılı...");
                }
                else
                {
                    MessageBox.Show("Bağlantı bulunamadı...");
                }
            }
           
        }

        private void menuYeniStokKayit_Click(object sender, EventArgs e)
        {   //Yeni stok ekleme formunu açar
            frmYeniStokKayit frm = new frmYeniStokKayit();
            frm.Show();
        }

        private void menuStokListesi_Click(object sender, EventArgs e)
        {    //Stokları listeleme ekranını açar
            frmStokListesi frm = new frmStokListesi();
            frm.Show();

        }

        private void menuYeniCariKayit_Click(object sender, EventArgs e)
        {   //Yeni cari ekleme formunu açar
            frmYeniCariKayit frm = new frmYeniCariKayit();
            frm.Show();
        }

        private void menuCariListesi_Click(object sender, EventArgs e)
        {   //Cari kayıtları listeleme ekranını açar
            frmCariListe frm = new frmCariListe();
            frm.Show();
        }
    }
}
