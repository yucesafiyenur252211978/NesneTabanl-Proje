﻿using FireSharp;
using FireSharp.Config;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using FireSharp.Response;
using MySqlX.XDevAPI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace NesneTabanliProje
{
    //Bu form, Firebase veritabanına stok ekleme ve stok güncelleme işlemlerini yapar.
    //Form açıldığında gelen ID bilgisine göre yeni kayıt mı yoksa düzenleme mi olduğu anlaşılır.
    //Kaydet butonuyla bilgiler Firebase’e yazılır, stok kodu otomatik artırılır ve işlem sonrası form temizlenir.
    public partial class frmYeniStokKayit : Form   //Form Tanımı 
    {

        public string id="";
        public string stokadi;
        public string stokbirim;                   //Public Değişkenler
        public string stokalisfiyati;
        public string stoksatisfiyati;
        public string aciklama;

        IFirebaseConfig config = new FirebaseConfig
        {   //Firebase veritabanına bağlanmak için gerekli bilgiler.
            AuthSecret = "egJlGzibXtQewvhJtCfYSAvV6unuXRFSmnoMMzwb",  
            BasePath = "https://nesnetabanliproje-333e4-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;  //client → Firebase işlemlerini yapan nesne.

        public frmYeniStokKayit()
        {
            //Form açıldığında: Arayüz yüklenir,Firebase bağlantısı kurulur, Alış / satış fiyatları 0 yapılır
            InitializeComponent();
            client = new FireSharp.FirebaseClient(config);
            txtAlisFiyati.Text = "0";
            txtSatisFiyati.Text = "0";
        }

        private void btnCikis_Click(object sender, EventArgs e)
        {
            this.Close();  // Formu kapatır.
        }

        private async void btnKaydet_Click(object sender, EventArgs e)
        {
            var data = new Data
            {
                //TextBox’lardaki bilgiler Data nesnesine aktarılır 

                StokID = txtStokID.Text,
                StokAdi = txtStokAdi.Text,
                StokBirim = cmbStokBirimi.Text,
                StokAlisFiyati = int.Parse(txtAlisFiyati.Text),
                StokSatisFiyati = int.Parse(txtSatisFiyati.Text),
                Acikalama= txtAciklama.Text
            };
            client = new FireSharp.FirebaseClient(config);
            SetResponse response = await client.SetTaskAsync("Stok/"+txtStokID.Text,data);
            Data.result = response.ResultAs<Data>();
            Temizle();

            //Eğer ID varsa → üzerine yazar (güncelleme) Yoksa → yeni kayıt ekler ,Kayıttan sonra form temizlenir
            //Firebase’de Set kullanıldığı için: Aynı ID → güncelleme, Yeni ID → ekleme
        }
        public void Temizle()
        {
            txtAciklama.Text = "";
            txtAlisFiyati.Text = "0";
            txtSatisFiyati.Text = "0";
            txtStokAdi.Text = "";
            txtStokID.Text = "";
            StokKoduArttirma();

        }
        string IDD = "";
        private void frmYeniStokKayit_Shown(object sender, EventArgs e)
        {// kaydey mi güncellemi karar veriliyor 
            if(id=="")
            {
                txtAlisFiyati.Text = "0";
                txtSatisFiyati.Text = "0";
                btnKaydet.Text = "Kaydet";
                StokKoduArttirma();

            }
            else
            {
                txtAciklama.Text = aciklama;
                txtAlisFiyati.Text = stokalisfiyati;
                txtSatisFiyati.Text = stoksatisfiyati;
                txtStokAdi.Text = stokadi;
                txtStokID.Text = id;
                cmbStokBirimi.Text = stokbirim;
                btnKaydet.Text = "Güncelle";

            }
        }

        public void StokKoduArttirma()
        { //Stok Kodu Arttırma, Otomatik stok ID üretir
            IFirebaseConfig config = new FirebaseConfig
            {
                AuthSecret = "egJlGzibXtQewvhJtCfYSAvV6unuXRFSmnoMMzwb",
                BasePath = "https://nesnetabanliproje-333e4-default-rtdb.firebaseio.com/"
            };

            IFirebaseClient client = new FirebaseClient(config);

            FirebaseResponse response = client.Get("Stok/");
            Dictionary<string, Data> getData = response.ResultAs<Dictionary<string, Data>>();

            foreach (var get in getData)
            {
                IDD = get.Value.StokID;
            }
            int SonID = int.Parse(IDD);
            SonID = SonID + 1;
            txtStokID.Text = SonID.ToString().PadLeft(4, '0');

            //Firebase’deki tüm stokları çeker En son stok ID’sini alır +1 artırır
            //4 haneli hale getirir(0001, 0002 gibi)
        }

        private void frmYeniStokKayit_Load(object sender, EventArgs e)
        {

        }
    }
}
