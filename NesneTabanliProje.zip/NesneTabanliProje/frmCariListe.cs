﻿using FireSharp;
using FireSharp;
using FireSharp.Config;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Interfaces;
using FireSharp.Response;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace NesneTabanliProje
{
    //Sistemdeki tüm cari kayıtlarını listeleyen ekrandır.
    //Cari ekleme, silme, düzenleme ve arama işlemleri buradan yapılır.
    public partial class frmCariListe : Form   //Form Tanımı
    {   //Public Değişkenler
        //Seçilen carinin bilgilerini düzenleme formuna göndermek için
        //Satırdan alınan bilgiler bu değişkenlere aktarılır frmYeniCariKayit formuna gönderilir
        public string id = " ";
        public string cariadi;
        public string vergidairesi;
        public string vergino;
        public string adres;
        public string sehir;
        public string telefon;
        public string yetkilikisi;
        public string aciklama;

        frmYeniCariKayit frm = new frmYeniCariKayit();
        public frmCariListe()
        {//Form Ayarları (Constructor)
            InitializeComponent(); //Grid’de satır tamamı seçilir
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.MultiSelect = false;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void frmCariListe_Load(object sender, EventArgs e)
        { //Form açılır açılmaz Liste çalışır Tüm cari kayıtlar ekrana yüklenir
            Listele();
        }
        public async void Listele()
        {
            //Firebase’deki tüm cari kayıtları çeker ve DataGridView’de gösterir Firebase "Cari" yolu okunur
            //Gelen veriler satır satır grid’e eklenir
            IFirebaseConfig config = new FirebaseConfig
            {
                AuthSecret = "egJlGzibXtQewvhJtCfYSAvV6unuXRFSmnoMMzwb",
                BasePath = "https://nesnetabanliproje-333e4-default-rtdb.firebaseio.com/"
            };

            IFirebaseClient client = new FirebaseClient(config);
            var data = await client.GetTaskAsync("Cari");

            Dictionary<string, CariData> data1 = data.ResultAs<Dictionary<string, CariData>>();

            foreach (var data2 in data1)
            {
                dataGridView1.Rows.Add(data2.Value.CariID,
                    data2.Value.CariAdi,
                    data2.Value.YetkiliKisi,
                    data2.Value.Sehir,
                    data2.Value.Telefon,
                    data2.Value.Aciklama);

            }
        }

        private void SagTik_Opening(object sender, CancelEventArgs e)
        {

        }

        private void SagTikYeniKayıt_Click(object sender, EventArgs e)
        {  //Sağ Tık → Yeni Kayıt
           //Yeni cari kayıt formu açılır Kayıttan sonra liste yenilenir
            frmYeniCariKayit frm = new frmYeniCariKayit();
            frm.ShowDialog();
            dataGridView1.Rows.Clear();
            Listele();
        }

        private async void SagTikSil_Click(object sender, EventArgs e)
        {    //Sağ Tık → Sil
             //Seçilen carinin ID’si alınır Firebase’den "Cari/id" silinir Kullanıcı bilgilendirilir Liste güncellenir
            id = dataGridView1.SelectedCells[0].Value.ToString();
            IFirebaseConfig config = new FirebaseConfig
            {
                AuthSecret = "egJlGzibXtQewvhJtCfYSAvV6unuXRFSmnoMMzwb",
                BasePath = "https://nesnetabanliproje-333e4-default-rtdb.firebaseio.com/"
            };

            IFirebaseClient client = new FirebaseClient(config);
            var data = await client.DeleteTaskAsync("Cari/" + id);
            MessageBox.Show("Kayıt silindi..");
            dataGridView1.Rows.Clear();
            Listele();
        }

        private void SagTikDuzenle_Click(object sender, EventArgs e)
        {
            //Sağ Tık → Düzenle
            //Seçilen cariyi düzenleme formuna gönderir Grid’den cari bilgileri alınır
            //frmYeniCariKayit formuna aktarılır Güncellemeden sonra liste yenilenir
            id = dataGridView1.SelectedCells[0].Value.ToString();
            cariadi = dataGridView1.SelectedCells[1].Value.ToString();
            yetkilikisi = dataGridView1.SelectedCells[2].Value.ToString();
            sehir = dataGridView1.SelectedCells[3].Value.ToString();
            telefon = dataGridView1.SelectedCells[4].Value.ToString();
            aciklama = dataGridView1.SelectedCells[5].Value.ToString();



            frm.id = id;
            frm.cariadi = cariadi;
            frm.yetkilikisi = yetkilikisi;
            frm.sehir = sehir;
            frm.telefon = telefon;
            frm.aciklama = aciklama;
            frm.ShowDialog();
            dataGridView1.Rows.Clear();
            Listele();
        }

        private void btnAra_Click(object sender, EventArgs e)
        {
            //Arama Butonu 
            if (txtArama.Text =="" && comboBox1.Text =="")
            {     //Arama alanı veya kriter boşsa kullanıcı uyarılır
                MessageBox.Show("Boş Alanları Doldurunuz...");
            }
            else
            {
                IFirebaseConfig config = new FirebaseConfig
                {
                    AuthSecret = "egJlGzibXtQewvhJtCfYSAvV6unuXRFSmnoMMzwb",
                    BasePath = "https://nesnetabanliproje-333e4-default-rtdb.firebaseio.com/"
                };
                //Firebase’den verileri çekme Tüm cari kayıtlar alınır Grid temizlenir
                IFirebaseClient client = new FirebaseClient(config);

                FirebaseResponse response = client.Get("Cari/");
                Dictionary<string, CariData> getData = response.ResultAs<Dictionary<string, CariData>>();

                dataGridView1.Rows.Clear();

                foreach (var get in getData)
                {  //Seçilen kritere göre arama yapılır .Cari Kodu, Cari Adı, Yetkili Kişi, Şehir, Eşleşen kayıtlar grid’e eklenir.
                    if (comboBox1.Text == "CARİ KODU")
                    {
                        string CariID = get.Value.CariID;
                        if (CariID == txtArama.Text)
                        {
                            dataGridView1.Rows.Add(get.Value.CariID,
                                get.Value.CariAdi,
                                get.Value.YetkiliKisi,
                                get.Value.Sehir,
                                get.Value.Telefon,
                                get.Value.Aciklama
                                );

                        }

                    }

                    if (comboBox1.Text == "CARİ ADI")
                    {
                        string CariAdi = get.Value.CariAdi;
                        if (CariAdi == txtArama.Text)
                        {
                            dataGridView1.Rows.Add(get.Value.CariID,
                                get.Value.CariAdi,
                                get.Value.YetkiliKisi,
                                get.Value.Sehir,
                                get.Value.Telefon,
                                get.Value.Aciklama
                                );

                        }

                    }

                    if (comboBox1.Text == "YETKİLİ KİŞİ")
                    {
                        string YetkiliKisi= get.Value.YetkiliKisi;
                        if (YetkiliKisi == txtArama.Text)
                        {
                            dataGridView1.Rows.Add(get.Value.CariID,
                                get.Value.CariAdi,
                                get.Value.YetkiliKisi,
                                get.Value.Sehir,
                                get.Value.Telefon,
                                get.Value.Aciklama
                                );

                        }

                    }

                    if (comboBox1.Text == "ŞEHİR")
                    {
                        string Sehir = get.Value.Sehir;
                        if (Sehir == txtArama.Text)
                        {
                            dataGridView1.Rows.Add(get.Value.CariID,
                                get.Value.CariAdi,
                                get.Value.YetkiliKisi,
                                get.Value.Sehir,
                                get.Value.Telefon,
                                get.Value.Aciklama
                                );

                        }

                    }
                }
            }
        }
    }
}
