﻿namespace NesneTabanliProje
{
    partial class frmStokListesi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.StokID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StokAdi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StokBirimi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StokAlisFiyati = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StokSatisFiyatı = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Aciklama = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SagTik = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.SagTikSil = new System.Windows.Forms.ToolStripMenuItem();
            this.SagTikDüzenle = new System.Windows.Forms.ToolStripMenuItem();
            this.SagTikYeniKayit = new System.Windows.Forms.ToolStripMenuItem();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.txtArama = new System.Windows.Forms.TextBox();
            this.btnAra = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SagTik.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.StokID,
            this.StokAdi,
            this.StokBirimi,
            this.StokAlisFiyati,
            this.StokSatisFiyatı,
            this.Aciklama});
            this.dataGridView1.ContextMenuStrip = this.SagTik;
            this.dataGridView1.Location = new System.Drawing.Point(254, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(779, 270);
            this.dataGridView1.TabIndex = 0;
            // 
            // StokID
            // 
            this.StokID.HeaderText = "Stok ID ";
            this.StokID.MinimumWidth = 6;
            this.StokID.Name = "StokID";
            this.StokID.ReadOnly = true;
            this.StokID.Width = 125;
            // 
            // StokAdi
            // 
            this.StokAdi.HeaderText = "Stok Adı";
            this.StokAdi.MinimumWidth = 6;
            this.StokAdi.Name = "StokAdi";
            this.StokAdi.ReadOnly = true;
            this.StokAdi.Width = 125;
            // 
            // StokBirimi
            // 
            this.StokBirimi.HeaderText = "Stok Şekli";
            this.StokBirimi.MinimumWidth = 6;
            this.StokBirimi.Name = "StokBirimi";
            this.StokBirimi.ReadOnly = true;
            this.StokBirimi.Width = 125;
            // 
            // StokAlisFiyati
            // 
            this.StokAlisFiyati.HeaderText = "Stok Alış Fiyatı";
            this.StokAlisFiyati.MinimumWidth = 6;
            this.StokAlisFiyati.Name = "StokAlisFiyati";
            this.StokAlisFiyati.ReadOnly = true;
            this.StokAlisFiyati.Width = 125;
            // 
            // StokSatisFiyatı
            // 
            this.StokSatisFiyatı.HeaderText = "Stok Satis Fiyatı";
            this.StokSatisFiyatı.MinimumWidth = 6;
            this.StokSatisFiyatı.Name = "StokSatisFiyatı";
            this.StokSatisFiyatı.ReadOnly = true;
            this.StokSatisFiyatı.Width = 125;
            // 
            // Aciklama
            // 
            this.Aciklama.HeaderText = "Açıklama";
            this.Aciklama.MinimumWidth = 6;
            this.Aciklama.Name = "Aciklama";
            this.Aciklama.ReadOnly = true;
            this.Aciklama.Width = 125;
            // 
            // SagTik
            // 
            this.SagTik.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.SagTik.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SagTikSil,
            this.SagTikDüzenle,
            this.SagTikYeniKayit});
            this.SagTik.Name = "SagTik";
            this.SagTik.Size = new System.Drawing.Size(143, 76);
            // 
            // SagTikSil
            // 
            this.SagTikSil.Name = "SagTikSil";
            this.SagTikSil.Size = new System.Drawing.Size(142, 24);
            this.SagTikSil.Text = "Sil";
            this.SagTikSil.Click += new System.EventHandler(this.SagTikSil_Click);
            // 
            // SagTikDüzenle
            // 
            this.SagTikDüzenle.Name = "SagTikDüzenle";
            this.SagTikDüzenle.Size = new System.Drawing.Size(142, 24);
            this.SagTikDüzenle.Text = "Düzenle";
            this.SagTikDüzenle.Click += new System.EventHandler(this.SagTikDüzenle_Click);
            // 
            // SagTikYeniKayit
            // 
            this.SagTikYeniKayit.Name = "SagTikYeniKayit";
            this.SagTikYeniKayit.Size = new System.Drawing.Size(142, 24);
            this.SagTikYeniKayit.Text = "Yeni Kayıt";
            this.SagTikYeniKayit.Click += new System.EventHandler(this.SagTikYeniKayit_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "STOK ID",
            "STOK ADI",
            "AÇIKLAMA"});
            this.comboBox1.Location = new System.Drawing.Point(35, 32);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(167, 24);
            this.comboBox1.TabIndex = 1;
            // 
            // txtArama
            // 
            this.txtArama.Location = new System.Drawing.Point(35, 81);
            this.txtArama.Name = "txtArama";
            this.txtArama.Size = new System.Drawing.Size(167, 22);
            this.txtArama.TabIndex = 2;
            // 
            // btnAra
            // 
            this.btnAra.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAra.Location = new System.Drawing.Point(35, 126);
            this.btnAra.Name = "btnAra";
            this.btnAra.Size = new System.Drawing.Size(167, 41);
            this.btnAra.TabIndex = 3;
            this.btnAra.Text = "ARA";
            this.btnAra.UseVisualStyleBackColor = true;
            this.btnAra.Click += new System.EventHandler(this.btnAra_Click);
            // 
            // frmStokListesi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1045, 450);
            this.Controls.Add(this.btnAra);
            this.Controls.Add(this.txtArama);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "frmStokListesi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Stok Listesi";
            this.Load += new System.EventHandler(this.StokListesi_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.SagTik.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn StokID;
        private System.Windows.Forms.DataGridViewTextBoxColumn StokAdi;
        private System.Windows.Forms.DataGridViewTextBoxColumn StokBirimi;
        private System.Windows.Forms.DataGridViewTextBoxColumn StokAlisFiyati;
        private System.Windows.Forms.DataGridViewTextBoxColumn StokSatisFiyatı;
        private System.Windows.Forms.DataGridViewTextBoxColumn Aciklama;
        private System.Windows.Forms.ContextMenuStrip SagTik;
        private System.Windows.Forms.ToolStripMenuItem SagTikSil;
        private System.Windows.Forms.ToolStripMenuItem SagTikDüzenle;
        private System.Windows.Forms.ToolStripMenuItem SagTikYeniKayit;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox txtArama;
        private System.Windows.Forms.Button btnAra;
    }
}