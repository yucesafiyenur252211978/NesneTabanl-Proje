﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using FireSharp; 


namespace NesneTabanliProje
{
    //Bu form, cari ekleme ve cari güncelleme işlemlerini Firebase veritabanı üzerinde gerçekleştirir.
    //Form açıldığında ID bilgisine bakılarak yeni kayıt mı yoksa düzenleme mi olduğu belirlenir.
    //Kaydet işlemiyle bilgiler Firebase’e yazılır, cari kodu otomatik artırılır ve form kullanıcıya göre kapatılır veya temizlenir.
    public partial class frmYeniCariKayit : Form  //Yeni cari kayıt ve cari güncelleme işlemleri bu formda yapılır
    {    //Public Değişkenler Cari listesi formundan seçilen verileri bu forma taşımak için
        public string id=" ";
        public string cariadi;
        public string vergidairesi;
        public string vergino;
        public string adres; 
        public string sehir; 
        public string telefon;
        public string yetkilikisi;
        public string aciklama;

        IFirebaseConfig config = new FirebaseConfig
        {    //Firebase Bağlantı Ayarları
            AuthSecret = "egJlGzibXtQewvhJtCfYSAvV6unuXRFSmnoMMzwb",
            BasePath = "https://nesnetabanliproje-333e4-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;

        public frmYeniCariKayit()
        {
            InitializeComponent();
        }

        private void btnCikis_Click(object sender, EventArgs e)
        {
            this.Close();   //Formu kapatır.
        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            if(id=="")
            {
                Kaydet();   //Yeni kayıt → Kaydet, form açık kalır
            }
            else
            {
                Kaydet();   //Güncelleme → Kaydet, form kapanır
                this.Close();    
            }
            
        }

        private async void Kaydet()
        {
            //Cari bilgilerini Firebase’e yazar TextBox’lardaki bilgiler CariData nesnesine aktarılır
            //"Cari/" + txtCariKodu.Text yoluna kaydedilir Aynı ID varsa → günceller Yoksa → yeni kayıt ekler
            //Sonrasında form temizlenir
            var data = new CariData
            {
                CariID = txtCariKodu.Text,
                CariAdi=txtCariAdi.Text,
                VergiDairesi=txtVergiDairesi.Text,
                VergiNo=txtVergiNo.Text,
                Adres =txtAdres.Text,
                Sehir=txtSehir.Text,
                Telefon =txtTelefon.Text,
                YetkiliKisi =txtYetkiliKisi.Text,
                Aciklama =txtAciklama.Text
            };
            client = new FireSharp.FirebaseClient(config);
            SetResponse response = await client.SetTaskAsync("Cari/" + txtCariKodu.Text, data);
            Data.result = response.ResultAs<Data>();
            Temizle();
        }
        public void Temizle()   //Tüm alanlar sıfırlanır
        {
            txtAciklama.Text = "";
            txtAdres.Text = "";
            txtCariAdi.Text = "";
            txtSehir.Text = "";
            txtTelefon.Text = "";
            txtVergiDairesi.Text = "";
            txtVergiNo.Text = "";
            txtYetkiliKisi.Text = "";
            CariKoduArttirma();
            
        }
        string IDD = "";
        private object txtsehir;

        public void CariKoduArttirma()  //Cari Kodu Arttırma
        {  
            IFirebaseConfig config = new FirebaseConfig
            {
                AuthSecret = "egJlGzibXtQewvhJtCfYSAvV6unuXRFSmnoMMzwb",
                BasePath = "https://nesnetabanliproje-333e4-default-rtdb.firebaseio.com/"
            };

            IFirebaseClient client = new FirebaseClient(config);

            FirebaseResponse response = client.Get("Cari/");
            Dictionary<string, CariData> getData = response.ResultAs<Dictionary<string, CariData>>();

            foreach (var get in getData)
            {
                IDD = get.Value.CariID;
            }
            int SonID = int.Parse(IDD);
            SonID = SonID + 1;
            txtCariKodu.Text = SonID.ToString().PadLeft(4, '0');
        }

        private void frmYeniCariKayit_Shown(object sender, EventArgs e)
        {   //Karar Mekanizması
            if (id == "")
            {
                //Yeni kayıt Buton → Kaydet Otomatik cari kod oluşturulur
                btnKaydet.Text = "Kaydet";
                CariKoduArttirma();

            }
            else
            {
                //Güncelleme Eski cari bilgileri textbox’lara doldurur Buton → Güncelle
                txtAciklama.Text = aciklama;
                txtAdres.Text = adres;
                txtCariAdi.Text =cariadi;
                txtCariKodu.Text = id;
                txtSehir.Text = sehir;
                txtTelefon.Text = telefon;
                txtVergiDairesi.Text = vergidairesi;
                txtVergiNo.Text = vergino;
                txtYetkiliKisi.Text = yetkilikisi;
                btnKaydet.Text = "Güncelle";

            }
           
        }

        private void frmYeniCariKayit_Load(object sender, EventArgs e)
        {

        }
    }
}
