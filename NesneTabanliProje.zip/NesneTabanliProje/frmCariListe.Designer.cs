﻿namespace NesneTabanliProje
{
    partial class frmCariListe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.CariID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CariAdi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.YetkiliKisi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sehir = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Telefon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Aciklama = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SagTik = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.SagTikSil = new System.Windows.Forms.ToolStripMenuItem();
            this.SagTikDuzenle = new System.Windows.Forms.ToolStripMenuItem();
            this.SagTikYeniKayıt = new System.Windows.Forms.ToolStripMenuItem();
            this.txtArama = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.btnAra = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SagTik.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CariID,
            this.CariAdi,
            this.YetkiliKisi,
            this.Sehir,
            this.Telefon,
            this.Aciklama});
            this.dataGridView1.ContextMenuStrip = this.SagTik;
            this.dataGridView1.Location = new System.Drawing.Point(212, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1105, 528);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // CariID
            // 
            this.CariID.HeaderText = "Cari Kodu";
            this.CariID.MinimumWidth = 6;
            this.CariID.Name = "CariID";
            this.CariID.Width = 125;
            // 
            // CariAdi
            // 
            this.CariAdi.HeaderText = "Cari Adı";
            this.CariAdi.MinimumWidth = 6;
            this.CariAdi.Name = "CariAdi";
            this.CariAdi.Width = 125;
            // 
            // YetkiliKisi
            // 
            this.YetkiliKisi.HeaderText = "Yetkili Kisi";
            this.YetkiliKisi.MinimumWidth = 6;
            this.YetkiliKisi.Name = "YetkiliKisi";
            this.YetkiliKisi.Width = 125;
            // 
            // Sehir
            // 
            this.Sehir.HeaderText = "Şehir";
            this.Sehir.MinimumWidth = 6;
            this.Sehir.Name = "Sehir";
            this.Sehir.Width = 125;
            // 
            // Telefon
            // 
            this.Telefon.HeaderText = "Telefon";
            this.Telefon.MinimumWidth = 6;
            this.Telefon.Name = "Telefon";
            this.Telefon.Width = 125;
            // 
            // Aciklama
            // 
            this.Aciklama.HeaderText = "Açıklama";
            this.Aciklama.MinimumWidth = 6;
            this.Aciklama.Name = "Aciklama";
            this.Aciklama.Width = 125;
            // 
            // SagTik
            // 
            this.SagTik.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.SagTik.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SagTikSil,
            this.SagTikDuzenle,
            this.SagTikYeniKayıt});
            this.SagTik.Name = "SagTik";
            this.SagTik.Size = new System.Drawing.Size(143, 76);
            // 
            // SagTikSil
            // 
            this.SagTikSil.Name = "SagTikSil";
            this.SagTikSil.Size = new System.Drawing.Size(142, 24);
            this.SagTikSil.Text = "Sil";
            this.SagTikSil.Click += new System.EventHandler(this.SagTikSil_Click);
            // 
            // SagTikDuzenle
            // 
            this.SagTikDuzenle.Name = "SagTikDuzenle";
            this.SagTikDuzenle.Size = new System.Drawing.Size(142, 24);
            this.SagTikDuzenle.Text = "Düzenle";
            this.SagTikDuzenle.Click += new System.EventHandler(this.SagTikDuzenle_Click);
            // 
            // SagTikYeniKayıt
            // 
            this.SagTikYeniKayıt.Name = "SagTikYeniKayıt";
            this.SagTikYeniKayıt.Size = new System.Drawing.Size(142, 24);
            this.SagTikYeniKayıt.Text = "Yeni Kayıt";
            this.SagTikYeniKayıt.Click += new System.EventHandler(this.SagTikYeniKayıt_Click);
            // 
            // txtArama
            // 
            this.txtArama.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtArama.Location = new System.Drawing.Point(25, 43);
            this.txtArama.Name = "txtArama";
            this.txtArama.Size = new System.Drawing.Size(181, 27);
            this.txtArama.TabIndex = 1;
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "CARİ KODU",
            "CARİ ADI",
            "YETKİLİ KİŞİ",
            "ŞEHİR"});
            this.comboBox1.Location = new System.Drawing.Point(25, 12);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(159, 28);
            this.comboBox1.TabIndex = 2;
            // 
            // btnAra
            // 
            this.btnAra.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAra.Location = new System.Drawing.Point(25, 76);
            this.btnAra.Name = "btnAra";
            this.btnAra.Size = new System.Drawing.Size(181, 38);
            this.btnAra.TabIndex = 3;
            this.btnAra.Text = "ARA";
            this.btnAra.UseVisualStyleBackColor = true;
            this.btnAra.Click += new System.EventHandler(this.btnAra_Click);
            // 
            // frmCariListe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1177, 562);
            this.Controls.Add(this.btnAra);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.txtArama);
            this.Controls.Add(this.dataGridView1);
            this.Name = "frmCariListe";
            this.Text = "Cari Liste";
            this.Load += new System.EventHandler(this.frmCariListe_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.SagTik.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn CariID;
        private System.Windows.Forms.DataGridViewTextBoxColumn CariAdi;
        private System.Windows.Forms.DataGridViewTextBoxColumn YetkiliKisi;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sehir;
        private System.Windows.Forms.DataGridViewTextBoxColumn Telefon;
        private System.Windows.Forms.DataGridViewTextBoxColumn Aciklama;
        private System.Windows.Forms.ContextMenuStrip SagTik;
        private System.Windows.Forms.ToolStripMenuItem SagTikSil;
        private System.Windows.Forms.ToolStripMenuItem SagTikDuzenle;
        private System.Windows.Forms.ToolStripMenuItem SagTikYeniKayıt;
        private System.Windows.Forms.TextBox txtArama;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button btnAra;
    }
}