﻿namespace NesneTabanliProje
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.stokİşlemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuYeniStokKayit = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStokListesi = new System.Windows.Forms.ToolStripMenuItem();
            this.cariİşlemlerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuYeniCariKayit = new System.Windows.Forms.ToolStripMenuItem();
            this.menuCariListesi = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stokİşlemleriToolStripMenuItem,
            this.cariİşlemlerToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // stokİşlemleriToolStripMenuItem
            // 
            this.stokİşlemleriToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuYeniStokKayit,
            this.menuStokListesi});
            this.stokİşlemleriToolStripMenuItem.Name = "stokİşlemleriToolStripMenuItem";
            this.stokİşlemleriToolStripMenuItem.Size = new System.Drawing.Size(112, 24);
            this.stokİşlemleriToolStripMenuItem.Text = "Stok İşlemleri";
            // 
            // menuYeniStokKayit
            // 
            this.menuYeniStokKayit.Name = "menuYeniStokKayit";
            this.menuYeniStokKayit.Size = new System.Drawing.Size(224, 26);
            this.menuYeniStokKayit.Text = "Yeni Stok Kayıt";
            this.menuYeniStokKayit.Click += new System.EventHandler(this.menuYeniStokKayit_Click);
            // 
            // menuStokListesi
            // 
            this.menuStokListesi.Name = "menuStokListesi";
            this.menuStokListesi.Size = new System.Drawing.Size(224, 26);
            this.menuStokListesi.Text = "Stok Listesi";
            this.menuStokListesi.Click += new System.EventHandler(this.menuStokListesi_Click);
            // 
            // cariİşlemlerToolStripMenuItem
            // 
            this.cariİşlemlerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuYeniCariKayit,
            this.menuCariListesi});
            this.cariİşlemlerToolStripMenuItem.Name = "cariİşlemlerToolStripMenuItem";
            this.cariİşlemlerToolStripMenuItem.Size = new System.Drawing.Size(105, 24);
            this.cariİşlemlerToolStripMenuItem.Text = "Cari İşlemler";
            // 
            // menuYeniCariKayit
            // 
            this.menuYeniCariKayit.Name = "menuYeniCariKayit";
            this.menuYeniCariKayit.Size = new System.Drawing.Size(224, 26);
            this.menuYeniCariKayit.Text = "Yeni Cari Kayıt";
            this.menuYeniCariKayit.Click += new System.EventHandler(this.menuYeniCariKayit_Click);
            // 
            // menuCariListesi
            // 
            this.menuCariListesi.Name = "menuCariListesi";
            this.menuCariListesi.Size = new System.Drawing.Size(224, 26);
            this.menuCariListesi.Text = "Cari Listesi";
            this.menuCariListesi.Click += new System.EventHandler(this.menuCariListesi_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ana Sayfa ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem stokİşlemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuYeniStokKayit;
        private System.Windows.Forms.ToolStripMenuItem menuStokListesi;
        private System.Windows.Forms.ToolStripMenuItem cariİşlemlerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuYeniCariKayit;
        private System.Windows.Forms.ToolStripMenuItem menuCariListesi;
    }
}

